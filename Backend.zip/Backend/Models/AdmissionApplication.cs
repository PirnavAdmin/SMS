namespace SMS.Api.Models;

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SMS.Api.Models.AcademicManagement;

[Table("admission_applications")]
public class AdmissionApplication
{
    [Key]
    public int Id { get; set; }

    public string? RegistrationNo { get; set; } // e.g. "REG-8244"

    // Profile Photo
    public string? ProfilePhotoUrl { get; set; }

    // 1. Student Personal Details
    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? Gender { get; set; } = "Male";

    public int? AppliedClassId { get; set; }
    public ClassGrade? AppliedClass { get; set; }

    public string? BranchName { get; set; } = "Main Campus";

    public string? BloodGroup { get; set; }
    public string? Religion { get; set; }
    public string? Caste { get; set; }

    // 2. Parent & Mobile Information
    public string? FatherName { get; set; }

    public string? MotherName { get; set; }

    [Phone]
    public string? FatherContact { get; set; }

    public string? MotherMobileNumber { get; set; }

    public string? AlternateMobileNumber { get; set; }

    [EmailAddress]
    public string? ParentEmail { get; set; }

    // 3. Complete Residential Address
    public string? HouseNo { get; set; }
    public string? Street { get; set; }
    public string? AreaLocality { get; set; }
    public string? City { get; set; }
    public string? District { get; set; }
    public string? State { get; set; }
    public string? PinCode { get; set; }

    // 4. Sibling Information
    public int? NumberOfSiblings { get; set; } = 0;
    public string? ExistingSiblingLookup { get; set; }

    // 5. Student Type & Facility Allocation - Transport
    public string? StudentType { get; set; } = "Day Scholar"; // "Day Scholar", "Hosteller"
    public bool? TransportRequired { get; set; } = false;
    public string? TransportType { get; set; }
    public string? BusRoute { get; set; }
    public string? PickupPoint { get; set; }
    public string? DropPoint { get; set; }

    // 5. Student Type & Facility Allocation - Hostel
    public string? HostelBlock { get; set; }
    public string? FloorLevel { get; set; }
    public string? HostelRoom { get; set; }
    public string? AvailableBed { get; set; }
    public string? AllocatedBedId { get; set; }

    // Financial Benefits
    public string? Scholarship { get; set; } = "None";
    public string? Discount { get; set; } = "None";

    public string? Status { get; set; } = "Pending"; // "Pending", "Rejected", "Enrolled"

    public bool IsDeleted { get; set; } = false;

    public DateTime? CreatedAt { get; set; } = DateTime.UtcNow;
}